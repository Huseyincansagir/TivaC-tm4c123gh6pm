﻿/*
 * Created by SharpDevelop.
 * User: MELİH
 * Date: 13.12.2020
 * Time: 12:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace uartproject
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnAc = new System.Windows.Forms.Button();
			this.btnKapat = new System.Windows.Forms.Button();
			this.btnGonder = new System.Windows.Forms.Button();
			this.btnSaat = new System.Windows.Forms.Button();
			this.textCom = new System.Windows.Forms.TextBox();
			this.textBaud = new System.Windows.Forms.TextBox();
			this.textData = new System.Windows.Forms.TextBox();
			this.textGonderilen = new System.Windows.Forms.TextBox();
			this.textSaat = new System.Windows.Forms.TextBox();
			this.textGelenler = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.textAnalog = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
			this.btnTemizle = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnAc
			// 
			this.btnAc.Location = new System.Drawing.Point(173, 9);
			this.btnAc.Name = "btnAc";
			this.btnAc.Size = new System.Drawing.Size(75, 23);
			this.btnAc.TabIndex = 0;
			this.btnAc.Text = "Aç";
			this.btnAc.UseVisualStyleBackColor = true;
			this.btnAc.Click += new System.EventHandler(this.BtnAcClick);
			// 
			// btnKapat
			// 
			this.btnKapat.Location = new System.Drawing.Point(254, 8);
			this.btnKapat.Name = "btnKapat";
			this.btnKapat.Size = new System.Drawing.Size(75, 23);
			this.btnKapat.TabIndex = 1;
			this.btnKapat.Text = "Kapat";
			this.btnKapat.UseVisualStyleBackColor = true;
			this.btnKapat.Click += new System.EventHandler(this.BtnKapatClick);
			// 
			// btnGonder
			// 
			this.btnGonder.Location = new System.Drawing.Point(173, 64);
			this.btnGonder.Name = "btnGonder";
			this.btnGonder.Size = new System.Drawing.Size(75, 23);
			this.btnGonder.TabIndex = 2;
			this.btnGonder.Text = "Gönder";
			this.btnGonder.UseVisualStyleBackColor = true;
			this.btnGonder.Click += new System.EventHandler(this.BtnGonderClick);
			// 
			// btnSaat
			// 
			this.btnSaat.Location = new System.Drawing.Point(211, 150);
			this.btnSaat.Name = "btnSaat";
			this.btnSaat.Size = new System.Drawing.Size(98, 23);
			this.btnSaat.TabIndex = 3;
			this.btnSaat.Text = "Saati Gönder";
			this.btnSaat.UseVisualStyleBackColor = true;
			this.btnSaat.Click += new System.EventHandler(this.BtnSaatClick);
			// 
			// textCom
			// 
			this.textCom.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.textCom.Location = new System.Drawing.Point(93, 12);
			this.textCom.Name = "textCom";
			this.textCom.Size = new System.Drawing.Size(74, 20);
			this.textCom.TabIndex = 4;
			this.textCom.Text = "COM3";
			this.textCom.TextChanged += new System.EventHandler(this.TextComTextChanged);
			// 
			// textBaud
			// 
			this.textBaud.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.textBaud.Location = new System.Drawing.Point(93, 38);
			this.textBaud.Name = "textBaud";
			this.textBaud.Size = new System.Drawing.Size(74, 20);
			this.textBaud.TabIndex = 5;
			this.textBaud.Text = "9600";
			// 
			// textData
			// 
			this.textData.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.textData.Location = new System.Drawing.Point(93, 64);
			this.textData.Name = "textData";
			this.textData.Size = new System.Drawing.Size(74, 20);
			this.textData.TabIndex = 6;
			this.textData.Text = "8";
			// 
			// textGonderilen
			// 
			this.textGonderilen.Location = new System.Drawing.Point(93, 102);
			this.textGonderilen.Multiline = true;
			this.textGonderilen.Name = "textGonderilen";
			this.textGonderilen.Size = new System.Drawing.Size(227, 44);
			this.textGonderilen.TabIndex = 7;
			// 
			// textSaat
			// 
			this.textSaat.Location = new System.Drawing.Point(93, 152);
			this.textSaat.Name = "textSaat";
			this.textSaat.Size = new System.Drawing.Size(112, 20);
			this.textSaat.TabIndex = 8;
			// 
			// textGelenler
			// 
			this.textGelenler.BackColor = System.Drawing.SystemColors.MenuText;
			this.textGelenler.ForeColor = System.Drawing.Color.Lime;
			this.textGelenler.Location = new System.Drawing.Point(12, 230);
			this.textGelenler.Multiline = true;
			this.textGelenler.Name = "textGelenler";
			this.textGelenler.Size = new System.Drawing.Size(308, 113);
			this.textGelenler.TabIndex = 9;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(50, 16);
			this.label1.TabIndex = 10;
			this.label1.Text = "COM";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(12, 41);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(50, 16);
			this.label2.TabIndex = 11;
			this.label2.Text = "BaudRate";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(12, 67);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(50, 16);
			this.label3.TabIndex = 12;
			this.label3.Text = "DataBiti";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(12, 100);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(75, 35);
			this.label4.TabIndex = 13;
			this.label4.Text = "Gönderilecek Mesaj";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(12, 155);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(50, 16);
			this.label5.TabIndex = 14;
			this.label5.Text = "Saat ";
			// 
			// textAnalog
			// 
			this.textAnalog.Location = new System.Drawing.Point(93, 176);
			this.textAnalog.Name = "textAnalog";
			this.textAnalog.Size = new System.Drawing.Size(112, 20);
			this.textAnalog.TabIndex = 15;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(9, 179);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(78, 17);
			this.label6.TabIndex = 16;
			this.label6.Text = "Analog Değer";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(127, 210);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(78, 17);
			this.label7.TabIndex = 17;
			this.label7.Text = "Gelen Veriler";
			// 
			// serialPort1
			// 
			this.serialPort1.PortName = "COM3";
			this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort1DataReceived);
			// 
			// btnTemizle
			// 
			this.btnTemizle.Location = new System.Drawing.Point(254, 64);
			this.btnTemizle.Name = "btnTemizle";
			this.btnTemizle.Size = new System.Drawing.Size(75, 23);
			this.btnTemizle.TabIndex = 18;
			this.btnTemizle.Text = "Temizle";
			this.btnTemizle.UseVisualStyleBackColor = true;
			this.btnTemizle.Click += new System.EventHandler(this.BtnTemizleClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.ClientSize = new System.Drawing.Size(332, 355);
			this.Controls.Add(this.btnTemizle);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.textAnalog);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textGelenler);
			this.Controls.Add(this.textSaat);
			this.Controls.Add(this.textGonderilen);
			this.Controls.Add(this.textData);
			this.Controls.Add(this.textBaud);
			this.Controls.Add(this.textCom);
			this.Controls.Add(this.btnSaat);
			this.Controls.Add(this.btnGonder);
			this.Controls.Add(this.btnKapat);
			this.Controls.Add(this.btnAc);
			this.Name = "MainForm";
			this.Text = "uartproject";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button btnTemizle;
		private System.IO.Ports.SerialPort serialPort1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textAnalog;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textGelenler;
		private System.Windows.Forms.TextBox textSaat;
		private System.Windows.Forms.TextBox textGonderilen;
		private System.Windows.Forms.TextBox textData;
		private System.Windows.Forms.TextBox textBaud;
		private System.Windows.Forms.TextBox textCom;
		private System.Windows.Forms.Button btnSaat;
		private System.Windows.Forms.Button btnGonder;
		private System.Windows.Forms.Button btnKapat;
		private System.Windows.Forms.Button btnAc;
	}
}

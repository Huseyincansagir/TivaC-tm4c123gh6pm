﻿/*
 * Created by SharpDevelop.
 * User: MELİH
 * Date: 13.12.2020
 * Time: 12:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace uartproject
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		string gelenveri=string.Empty;
		
		void BtnAcClick(object sender, EventArgs e)
		{
			if (!serialPort1.IsOpen)
			{
				serialPort1.PortName=textCom.Text;
				serialPort1.BaudRate=Convert.ToInt32(textBaud.Text);
				serialPort1.DataBits=Convert.ToInt32(textData.Text);
				serialPort1.Open();
			}
		}
		
		void BtnKapatClick(object sender, EventArgs e)
		{
			if(serialPort1.IsOpen)
			{
				serialPort1.Close();
			}
		}
		
		void BtnGonderClick(object sender, EventArgs e)
		{
			serialPort1.Write(textGonderilen.Text);	
		}
		void SerialPort1DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
		{
			gelenveri=serialPort1.ReadExisting();
			this.Invoke(new EventHandler(DisplayText));
		}
		
		private void DisplayText(object sender, EventArgs e){
			
			if(gelenveri=="+")
			textAnalog.Text=gelenveri;
			textGelenler.Text=textGelenler.Text + gelenveri;
			
		}
		
		
		void BtnSaatClick(object sender, EventArgs e)
		{
			serialPort1.Write(textSaat.Text);
		}
		
		void BtnTemizleClick(object sender, EventArgs e)
		{
			if(serialPort1.IsOpen)
			serialPort1.Write("#");
			textGonderilen.Clear();
			textGelenler.Clear();
		}
		
		void TextComTextChanged(object sender, EventArgs e)
		{
			
		}
	}
}
